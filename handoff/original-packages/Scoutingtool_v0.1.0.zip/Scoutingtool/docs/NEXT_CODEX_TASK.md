# Eerstvolgende Codex-opdracht

**Status: voorbereid, niet gestart.** Deze opdracht beschrijft vervolgbouw op de bestaande lokale toepassing. Maak niet opnieuw alleen een ontwerpdocument.

## Prompt voor de volgende ontwikkelsessie

Je werkt aan Omni-Scout in de door de eigenaar aangewezen repository `chatgpt20251991/Scoutingtool`. Lees `AGENTS.md`, `README.md`, `docs/BUILD_BRIEF.md` en `docs/IMPLEMENTATION_STATUS.md`. Controleer welke code daadwerkelijk in de checkout staat; de eerdere GitHub-overdracht is mislukt met 403. Importeer het meegeleverde bronpakket alleen in de toegestane projectmap en overschrijf geen andere bestaande wijzigingen.

1. Voer eerst `npm run verify` uit. Bewaar de werkende responsive radar en de scheiding tussen gedocumenteerde en verkennende kandidaten.
2. Voer browser-naar-lokale-backendtests uit in een omgeving waar lokale navigatie toegestaan is. Verifieer herladen, schijfopslag, CSV-download en foutmeldingen. Verander geen managed browserbeleid om de test te forceren.
3. Bouw als eerste nieuwe functie een begrensde, lokale JSON-importflow voor door de gebruiker verstrekte, rechtmatig beschikbare clubdata. Voeg een concreet versieerbaar importschema en synthetisch voorbeeldbestand toe. Geen scraping of betaalde provider nodig voor deze stap.
4. Laat de gebruiker eerst de inhoud, gebruikte bronrechten, seizoenen, peildatum, identiteitsconflicten en ontbrekende velden controleren. Schrijf niets als validatie faalt. Bewaar bronmetadata en provenance; leid ontbrekende statistieken niet af.
5. Importeer idempotent met unieke bron-/snapshot-/observatie-ID's. Dezelfde bron opnieuw inlezen mag niet tot dubbele ontdekkingen of fictieve trends leiden. Maak elke import herleidbaar en herstelbaar zonder de vorige waarneming te overschrijven.
6. Houd synthetische demo's en echte imports strikt gescheiden. Echt betekent hier 'geïmporteerd uit opgegeven bron', niet 'onafhankelijk geverifieerd' of 'voorspellend bewezen'. Geen echte spelersdata in Git of tests publiceren.
7. Maak uitbreiding via adapters mogelijk. Een provideradapter mag later alleen worden verbonden na autorisatie, rechtencontrole, kostenplafond en veilige credentialconfiguratie. Gebruik het taalmodel niet voor deterministische rekentaken.
8. Laat echte klantdata buiten het prototype totdat productie-authenticatie, organisatiescheiding, bewaarbeleid en relevante juridische beoordeling gereed zijn. Implementeer die in een afzonderlijke gecontroleerde vervolgstap met cross-tenant negatieve tests.

## Acceptatietests voor dit nieuwe pakket

- Ongeldig JSON, te groot bestand, onbekende schema-versie en onbekende meetdefinities worden expliciet geweigerd.
- Minderjarigen, onduidelijke identiteit of niet-toegestane bronrechten worden niet stilzwijgend toegelaten.
- Twee dezelfde namen leveren niet automatisch één speler op.
- Null minuten blijven null; een broncorrectie veroorzaakt geen schijntrend.
- Een dubbele import wijzigt aantallen niet, een nieuwe versie bewaart de oude provenance.
- Geen toekomstige waarnemingen in historische dossiers.
- Importbevestiging noemt daadwerkelijke records en dekking; ontbrekende competities worden niet als talentloos gelabeld.
- UI, lokale API, export en herladen werken samen in een echte lokale browsertest.
- Testbestand bevat uitsluitend synthetische gegevens; geen uploads in repository of openbare logs.

## Oplevering

Maak een branch/PR als de repositorytoegang dat werkelijk toestaat. Lever werkende code, tests, migratie-/rollbacknotities, commando's, ruwe resultaten en concrete nog open risico's. Publiceer of deploy niet zonder daarvoor geldige autorisatie. Meld nooit dat een task, commit, live databron of worker actief is zonder dat het overeenkomstige toolresultaat dat bevestigt.
