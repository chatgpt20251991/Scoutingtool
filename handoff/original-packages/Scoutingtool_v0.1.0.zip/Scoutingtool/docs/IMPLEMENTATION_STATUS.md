# Feitelijke implementatiestatus

**8 september 2026 · versie 0.1.0.** De meegeleverde `BUILD_BRIEF.md` is de oorspronkelijke uitgebreide specificatie. Het bestaan van die specificatie betekent niet dat alle hoofdstukken al zijn gerealiseerd.

| Onderdeel | Status |
|---|---|
| Responsieve radar, filters, spelerkaarten | Gebouwd en interface getest met fictieve gegevens. |
| Rolgegevens, ontbrekende cijfers, steekproeven | Deterministische code en tests aanwezig. |
| Onderzoek, shortlist, vergelijking, clubvraag | Gebouwd; lokale API en interface afzonderlijk getest. |
| Bronstatus, timestamps, counterevidence | In het prototypemodel aanwezig; geen echte providerrechten geverifieerd. |
| Lokale opslag en mutatielog | Gebouwd, Node-tests voor opslag en concurrente mutaties geslaagd. |
| CSV met brongegevens | Code en API getest; browserdownload niet in deze omgeving end-to-end getest. |
| Snapshotvalidatie | Helper met tests; geen operationele echte-data-importer. |
| Wereldwijde echte dekking | Niet aangesloten. Twaalf spelers en acht competities zijn fictief. |
| Cloudflare | Alleen-lezen demo-handler en configuratie; geen runtime-/deploytest. |
| Productie-tenantisolatie | Niet geïmplementeerd. Eén lokale gebruiker. |
| LLM / getraind voorspelmodel | Niet gebruikt of gebouwd. |
| GitHub code / PR / CI | Niet gepubliceerd; schrijfpoging gaf HTTP 403. |
| Codex-agenttaak | Niet gestart. Overdrachtsinstructies zijn bestanden, geen actieve taak. |
| Privacy/rechten/regulatoire toets | Nog uit te voeren voor echte toepassing. |
| Verbeterde scoutingkwaliteit | Niet aangetoond. Softwaretests zijn geen sportwetenschappelijke evaluatie. |

## Open acceptatiecriteria uit de volledige specificatie

Echte tenantisolatie inclusief gemanipuleerde IDs, bronadaptercontracten tegen echte toegestane data, volledige geversioneerde waarnemingen/correcties, providerlicentielevenstijd, echte multimodale bewijsverwerking, gesloten onderzoekslus met onafhankelijke menselijke observaties en evaluatie op toekomstige voetbaluitkomsten blijven open.

Een unit test van een rights-checkfunctie bewijst niet dat bestaande datalicenties de commerciële verwerking toestaan. Een as-of-helper bewijst niet dat alle historische providerdata destijds beschikbaar waren. Een UI-voorbeeld van een onderzoekstaak is nog geen daadwerkelijk uitgevoerde scoutingobservatie.

## Overdracht

De GitHub-repository is via metadata gevonden als `chatgpt20251991/Scoutingtool`, openbaar en op dat moment leeg. `create_file(AGENTS.md)` gaf `Resource not accessible by integration` met status 403. De daaropvolgende zoekactie binnen toegestane repositories vond geen match. Er is geen alternatieve route gebruikt om deze toegang te omzeilen.

De geleverde ZIP bevat de daadwerkelijke code en de ruwe testresultaten. Publicatie en Codex-start moeten later ieder afzonderlijk worden bevestigd met hun werkelijke resultaat.
