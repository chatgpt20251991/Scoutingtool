# Omni-Scout · Scoutingtool

**Versie 0.1.0 — werkend lokaal onderzoeksprototype, 8 september 2026.**

Ontdek kandidaten, onderzoek het bewijs en leg de volgende scoutingactie vast. De wereldwijde radar omvat nadrukkelijk ook lagere divisies als productdoel. De huidige versie demonstreert de werkwijze met **12 fictieve volwassen spelers, 8 fictieve competities en 0 live databronnen**. Land- en regiobenamingen zijn geen bewijs van echte dekking.

Dit pakket bevat broncode, een startbare toepassing, een losse HTML-demo, tests en ruwe testresultaten. Het is geen productieplatform, geen gevalideerd talentvoorspelmodel en geen aangesloten wereldwijde database.

## Meteen bekijken

Open `OmniScout-preview.html` in een normale desktopbrowser. Het bestand bevat de benodigde code en vormgeving; een server of API-sleutel is hiervoor niet nodig. Interactie gebruikt browseropslag als die beschikbaar is. Anders schakelt de demo zichtbaar over op tijdelijk geheugen; wijzigingen verdwijnen dan na sluiten of herladen. Browserbeleid kan het openen van lokale bestanden beperken.

De sterkere lokale variant hieronder bewaart beslissingen, onderzoeksopdrachten en de clubvraag in een bestand.

## Lokaal starten

Benodigd: Node.js 22 of nieuwer. Deze versie heeft geen externe npm-afhankelijkheden.

**Windows:** pak de hele ZIP uit en dubbelklik `START_WINDOWS.cmd`. Laat het terminalvenster open zolang je de toepassing gebruikt. Het script installeert zelf niets.

**Terminal, vanuit de projectmap:**

```sh
npm start
```

Open vervolgens `http://127.0.0.1:4173`. Stop de server met Ctrl+C. Voor een andere vrije lokale poort kan de omgevingsvariabele `PORT` worden ingesteld.

De server luistert uitsluitend op loopback. Publiceer deze lokale server niet met een tunnel of omgekeerde proxy als klantomgeving. Er zijn nog geen productieaccounts of organisatiescheidingen.

## Wat werkt

| Onderdeel | Werking in deze versie |
|---|---|
| Wereldradar | Regio's, lagere niveaus, filterbare kandidaten en zichtbare gaten in de fictieve dekking. |
| Ontdekking | Uitlegbare voorbeeldsignalen; aparte lijsten voor beter gedocumenteerde en verkennende kandidaten. |
| Filters | Naam, club, land, rol, regio, leeftijd, lagere niveaus en bekendheid binnen de lokale shortlist/beslisgegevens. |
| Spelersdossiers | Rolgegevens, steekproefomvang, bronverwijzingen, tegenbewijs, ontbrekende gegevens en vervolgvraag. |
| Shortlist en vergelijking | Bewaren en maximaal drie spelers naast elkaar vergelijken, zonder universele talentscore. |
| Onderzoek | Een interne taak maken, schriftelijke uitkomst vastleggen, afronden en heropenen. Er wordt niemand automatisch benaderd. |
| Clubvraag | Gestructureerde rol- en leeftijdskeuzes toepassen; vrije tekst bewaren zonder te doen alsof die met AI is geïnterpreteerd. |
| Dekking | Uitslagen, opstellingen, minuten, spelerstatistieken, eventdata, tracking en video afzonderlijk. |
| Beslislog en export | Lokale wijzigingen terugzien; CSV met brongegevens en expliciet fictieve status. |
| Mobiel | Kaartenweergave van kandidaten, filters, dossier en navigatie. |

Alle signaaldrempels zijn **demonstratieregels**, geen wetenschappelijk gekalibreerde scoutingnormen. Een gedocumenteerde fictieve kandidaat is nog steeds fictief. Doelpunten worden niet als universele maat voor iedere rol gebruikt. Onbekende minuten blijven onbekend; de toepassing rekent dan geen statistiek per 90 minuten uit.

## Opslag en privacy van de demo

De Node-server bewaart lokale status in `.local/state.json`. De map wordt niet meegeleverd of in Git opgenomen. De broncatalogus zelf staat als synthetische fixture in `src/fixtures.mjs`. De JSON-opslag is bedoeld voor één lokale gebruiker en één serverproces; het is geen gedeelde database of versleuteld dossierarchief. Een kapot bestand veroorzaakt een expliciete fout en wordt niet stilzwijgend gewist.

Een lokaal sessietoken, hostcontrole en origincontrole beschermen schrijfacties tegen bepaalde onbedoelde browserverzoeken. Dit is **geen vervanging voor productie-authenticatie, rollen, tenant-isolatie of een security-audit**. Het beslislog is via de toepassing chronologisch, maar niet bestand tegen handmatige bestandsmanipulatie.

Voer nog geen echte vertrouwelijke clubgegevens in. De beoogde GitHub-repository was bij inspectie openbaar. Geheimen, providerkeys en klantdossiers horen niet in broncode, screenshots, demo's of Git.

## Testen en bouwen

```sh
npm run verify
```

Dit voert syntaxcontroles, de Node-tests en de preview-build uit. Met `npm ci --ignore-scripts` kan het meegeleverde lockbestand worden gecontroleerd; er zijn momenteel nul externe npm-pakketten nodig.

Werkelijk uitgevoerd bij deze levering: **55 geslaagde logica-, API-, opslag- en workercontroles**, plus **13 geslaagde Chromium-interfacecontroles** van de ingeladen zelfstandige HTML. Zie `reports/VERIFICATION.md` en de ruwe rapporten.

De testbrowser blokkeerde navigatie naar lokale HTTP- en bestandsadressen. Daarom werd de interface in browsergeheugen geladen. De HTTP-API en schijfopslag zijn apart via Node getest, niet als één volledige browser-naar-backendtest. Geen claim dat alle browsers, besturingssystemen, toegankelijkheidseisen of productieomstandigheden zijn getest.

Optionele browsercontroles vereisen Python, het Python-pakket Playwright en een geïnstalleerde Chromium. `CHROMIUM_PATH` wijst zo nodig naar de browser. In een omgeving die lokale navigatie toestaat:

```sh
python tools/browser-tests.py
```

In deze bouwomgeving is werkelijk uitgevoerd:

```sh
python tools/browser-tests.py --content-only
```

Screenshots staan in `reports/`. Ze tonen de werkende fictieve interface, geen echte scoutbevindingen.

## Cloudflare-worker: voorbereid, niet gepubliceerd

`worker/index.mjs` levert een alleen-lezen demonstratie-API. `wrangler.jsonc` wijst naar de gegenereerde bestanden in `dist/`. `run_worker_first: true` zorgt er volgens het beoogde routeringscontract voor dat ook statische antwoorden via de workerheaders lopen.

Deze worker is **geen crawler of geplande gegevensverwerker**. Er zijn geen cronjobs, queues, providerverbindingen, cloudaccounts of geheime sleutels ingesteld. Alleen de handler is met Node en een nagebootste ASSETS-binding getest. Wrangler/workerd en een echte Cloudflare-deployment zijn niet uitgevoerd. Er is ook geen cloudopslag voor beslissingen: de webinterface valt zonder de lokale sessie-API terug op browseropslag.

Zie `docs/ARCHITECTURE.md` voor de scheiding tussen lokale toepassing, losse preview en edge-demo.

## GitHub en Codex

Doelrepository: `chatgpt20251991/Scoutingtool`.

De repository is gevonden. De poging om `AGENTS.md` via de GitHub-koppeling te schrijven is geweigerd met **HTTP 403 — Resource not accessible by integration**. De aangesloten-repositoryzoekopdracht vond vervolgens nog steeds geen toegankelijke match.

**Dit pakket is daarom niet naar GitHub gepusht. Er is geen commit, pull request, GitHub Actions-run of Codex-taak gestart.** De bestanden zijn lokaal gebouwd en als overdrachtspakket geleverd.

Voor verdere ontwikkeling staan de oorspronkelijke specificatie in `docs/BUILD_BRIEF.md`, de feitelijke implementatiestatus in `docs/IMPLEMENTATION_STATUS.md` en de eerstvolgende afgebakende ontwikkelopdracht in `docs/NEXT_CODEX_TASK.md`. De aanwezigheid van deze opdracht start geen agent.

## Bestandsindeling

```text
public/                Interface, vormgeving en lokale/browseropslagadapter
src/engine.mjs         Deterministische analyse, provenance en zoekfilters
src/fixtures.mjs       Expliciet fictieve catalogus
src/server.mjs         Loopback-HTTP-server en gevalideerde API
src/store.mjs          Geserialiseerde lokale JSON-opslag
worker/index.mjs       Alleen-lezen edge-demo
tests/                Logica-, server- en workertests
tools/                Syntaxcheck, fixturegenerator, previewbuild en browsertest
docs/                 Specificatie, architectuur, status en Codex-opdracht
reports/              Ruwe testresultaten en screenshots
```

## Voordat echte scouts dit gebruiken

Eerst echte toegestane data aansluiten, bronrechten vastleggen, identiteit en dekking valideren, server-side accounts en organisatiescheiding realiseren en de benodigde privacy/juridische beoordeling uitvoeren. Daarna prospectief meten of dit werkelijk betere scoutingacties oplevert. Deze stappen zijn nog niet voltooid.

Er is nog geen opensourcelicentie gekozen of namens de eigenaar verleend.
